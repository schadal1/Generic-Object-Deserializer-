package genericDeser.driver;
import java.io.File;

import genericDeser.logger.Logger;
import genericDeser.util.PopulateObjects;

public class Driver {

	
	
	
	public static void main(String[] args)
	{
		if(args.length!=2)
		{
			System.out.println("Wrong No of Command Line Arguments,Please enter Correct number of Arguments ");
		}
		else
		{			
			Logger.setDebugValue(Integer.parseInt(args[1]));
			handleArgs(args);
			PopulateObjects pObs = new PopulateObjects();
			pObs.deserObjects(args[0]);
			
			Logger.writeMessage("Total Number of First Objects : " + pObs.getFirst(), Logger.DebugLevel.zero);
			Logger.writeMessage("Total Number of Unique First Objects : " + pObs.getuniqueFirst(), Logger.DebugLevel.zero);
			Logger.writeMessage("Total Number of Second Objects : " + pObs.getFirst(), Logger.DebugLevel.zero);
			Logger.writeMessage("Total Number of Unique Second Objects : " + pObs.getUniqueSecond(), Logger.DebugLevel.zero);
			
		}		
	}
	public static  void handleArgs(String[] args)
	{
		try{
		File file=new File(args[0]);
		file=null;
		}
		catch(Exception e){
		e.printStackTrace();
        System.exit(0);
		}
		try
		{
			int loggerValue=Integer.parseInt(args[1]);
			if(loggerValue<0 || loggerValue>2)
			{
				System.out.println("Second argument "+args[1]+" should be an integer value 1 or 2 or 3");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}
