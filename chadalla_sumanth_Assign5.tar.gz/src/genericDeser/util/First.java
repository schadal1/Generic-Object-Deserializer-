package genericDeser.util;

import genericDeser.logger.Logger;

public class First {

	private int IntValue;
	private String StringValue;
	private float FloatValue;
	private short ShortValue;
	public static int count=0;

	
    @Override
    public int hashCode() {
        int hash = 7;
        hash = hash * 17 + IntValue;
        if(StringValue!=null)
        hash = hash * 31 + StringValue.hashCode();
        hash = hash * 17 + (int) FloatValue;
        hash = hash * 31 + ShortValue;
        return hash;
    }
	
    @Override
    public boolean equals(Object object)
    {

		Logger.writeMessage("Overriden equals() : Comparing 2 First Objects.", Logger.DebugLevel.one);
    	First firstObject = (First) object;
    	
    	if(firstObject.getIntValue()==IntValue)
    	{
    		if(firstObject.getFloatValue()==FloatValue)
    		{
    			if(firstObject.getShortValue()==ShortValue)
    			{
    				
    				if(StringValue!=null)
    				{
    				if(firstObject.getStringValue().equals(StringValue))
    				{
    					return true;
    				}
    				}
    				else
    				if(firstObject.getStringValue()==null)
    					return true;
    			}
    		}
    	}
    	return false;
    }
    
	public static void IncrementCount()
	{
		Logger.writeMessage("A duplicate in first class found.", Logger.DebugLevel.two);
		++count;
	}
	public int getIntValue() {
		return IntValue;
	}
	public void setIntValue(int intValue) {
		IntValue = intValue;
	}
	public String getStringValue() {
		return StringValue;
	}
	public void setStringValue(String stringValue) {
		StringValue = stringValue;
	}
	public float getFloatValue() {
		return FloatValue;
	}
	public void setFloatValue(float floatValue) {
		FloatValue = floatValue;
	}
	public short getShortValue() {
		return ShortValue;
	}
	public void setShortValue(short shortValue) {
		ShortValue = shortValue;
	}
	
}
