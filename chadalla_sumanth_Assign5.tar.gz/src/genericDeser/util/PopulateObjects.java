package genericDeser.util;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

import genericDeser.fileOperations.FileProcessor;
import genericDeser.util.First;
import genericDeser.util.Second;

public class PopulateObjects {
	private First first;
	private Second second;
	private String InputLine;
	private FileProcessor fp;
	private HashMap<Integer, ArrayList<First>> Firsthmap = new HashMap<Integer, ArrayList<First>>();
	private HashMap<Integer, ArrayList<Second>> Secondhmap = new HashMap<Integer, ArrayList<Second>>();
	private Class cls;
	private Object obj;
	private String clsName;

	
	public int getFirst()
	{
		return First.count;
	}
	
	public int getuniqueFirst()
	{
	
		
		Set<Entry<Integer, ArrayList<First>>> set = Firsthmap.entrySet();
		
		Iterator<Entry<Integer, ArrayList<First>>> it = set.iterator();
		int firstCount=0;
		while(it.hasNext())
		{
			firstCount = firstCount + it.next().getValue().size();
		}
		return (firstCount);
	}
	
	public int getSecond()
	{
		return Second.count;
	}
	
	public int getUniqueSecond()
	{
		Set<Entry<Integer, ArrayList<Second>>> setS = Secondhmap.entrySet();
		
		Iterator<Entry<Integer, ArrayList<Second>>> itS = setS.iterator();
		int secondCount=0;
		while(itS.hasNext())
		{
			secondCount = secondCount + itS.next().getValue().size();
		}
		return(secondCount);
	}
	
	public void deserObjects(String InputFile)
	{
		fp=FileProcessor.getInstance(InputFile);
		int input;
		int currentIndex;
		String valueInput;

		while(fp.hasNext())
		{
			InputLine=fp.getNextLine();
			input=decideAndCreateObject(InputLine);
			action(input,InputLine);
		}
		
		if(second!=null)
		{
			if(Secondhmap.get(second.hashCode())==null)
			{
				ArrayList al = new ArrayList<Second>();
				al.add(second);
				Secondhmap.put(second.hashCode(), al);
			}
			else
			{
				int i =0;
				ArrayList al = Secondhmap.get(second.hashCode());
				Iterator<Second> it = al.iterator();
				while(it.hasNext())
				{
					if(it.next().equals(second))
						i++;
				}
				
				if(i==0)
					al.add(second);
			}
			second=null;
		}
		if(first!=null)
		{
			if(Firsthmap.get(first.hashCode())==null)
			{
				ArrayList al = new ArrayList<First>();
				al.add(first);
				Firsthmap.put(first.hashCode(), al);
			}
			else
			{
				int i =0;
				ArrayList al = Firsthmap.get(first.hashCode());
				Iterator<First> it = al.iterator();
				while(it.hasNext())
				{
					if(it.next().equals(first))
						i++;
				}
				
				if(i==0)
					al.add(first);
			}
			first=null;
		}

	}
	
	
	public int decideAndCreateObject(String InputLineIn)
	{
		if(InputLine.startsWith("fqn"))
		{
			if(InputLine.endsWith("First"))
			{
				return 1;
			}
			else //if(InputLine.endsWith("Second"))
			{
				return 2;
			}
	
		}
		else
		{
			return 3;
		}
	}	
	
	private void action(int input, String InputLine)
	{
		try{
			
		switch (input)
		{
			case 1:
				if(second!=null)
				{
					if(Secondhmap.get(second.hashCode())==null)
					{
						ArrayList al = new ArrayList<Second>();
						al.add(second);
						Secondhmap.put(second.hashCode(), al);
					}
					else
					{
						int i =0;
						ArrayList al = Secondhmap.get(second.hashCode());
						Iterator<Second> it = al.iterator();
						while(it.hasNext())
						{
							if(it.next().equals(second))
								i++;
						}
						
						if(i==0)
							al.add(second);
					}
					second=null;
				}
				if(first!=null)
				{
					if(Firsthmap.get(first.hashCode())==null)
					{
						ArrayList al = new ArrayList<First>();
						al.add(first);
						Firsthmap.put(first.hashCode(), al);
					}
					else
					{
						int i =0;
						ArrayList al = Firsthmap.get(first.hashCode());
						Iterator<First> it = al.iterator();
						while(it.hasNext())
						{
							if(it.next().equals(first))
								i++;
						}
						
						if(i==0)
							al.add(first);
					}
					first=null;
				}
				 clsName = "genericDeser.util.First";
				 cls = Class.forName(clsName); 
				 obj = cls.newInstance(); 
				 first=(First)obj;
				 First.IncrementCount();
				break;				
			case 2:
				if(second!=null)
				{
					if(Secondhmap.get(second.hashCode())==null)
					{
						ArrayList al = new ArrayList<Second>();
						al.add(second);
						Secondhmap.put(second.hashCode(), al);
					}
					else
					{
						int i =0;
						ArrayList al = Secondhmap.get(second.hashCode());
						Iterator<Second> it = al.iterator();
						while(it.hasNext())
						{
							if(it.next().equals(second))
								i++;
						}
						
						if(i==0)
							al.add(second);
					}
					second=null;
				}
				if(first!=null)
				{
					if(Firsthmap.get(first.hashCode())==null)
					{
						ArrayList al = new ArrayList<First>();
						al.add(first);
						Firsthmap.put(first.hashCode(), al);
					}
					else
					{
						int i =0;
						ArrayList al = Firsthmap.get(first.hashCode());
						Iterator<First> it = al.iterator();
						while(it.hasNext())
						{
							if(it.next().equals(first))
								i++;
						}
						
						if(i==0)
							al.add(first);
					}
					first=null;
				}
				 clsName = "genericDeser.util.Second";
				 cls = Class.forName(clsName); 
				 obj = cls.newInstance(); 
				 second=(Second)obj;
				 Second.IncrementCount();
				break;
			case 3:
					String strings[] = InputLine.split(",");
					String type = (strings[0].trim()).substring(5);
					String var = (strings[1].trim()).substring(4);
					String value = (strings[2].trim()).substring(6);

					 Class[] signature = new Class[1]; 
					 setSignature(signature, type);		
					 String methodName = "set" + var; 	
					 
					 Method meth = cls.getMethod(methodName, signature); 
					 Object[] params = new Object[1]; 
					 setParameters(params, type, value);		
					 Object result = meth.invoke(obj, params); 		
				break;
			default:
				break;
		}
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	
	
	private void setParameters(Object[] param, String type, String value)
	{
		switch(type)
		{
		case "int":
				param[0]= new Integer(Integer.parseInt(value));
				break;
		case "short":
				param[0]= new Short(Short.parseShort(value));
				break;
		case "double":
				param[0]= new Double(Double.parseDouble(value));
				break;
		case "float":
				param[0]= new Float(Float.parseFloat(value));
				break;
		case "boolean":
				param[0]= new Boolean(Boolean.parseBoolean(value));
				break;
		case "String":
				param[0]= value;
				break;
		default:
				break;
		
		}
		
	}
	
	private void setSignature(Class[] sig, String type)
	{
		switch(type)
		{
		case "int":
				sig[0]=Integer.TYPE;
				break;
		case "short":
				sig[0]=Short.TYPE;
				break;
		case "double":
				sig[0]=Double.TYPE;
				break;
		case "float":
				sig[0]=Float.TYPE;
				break;
		case "boolean":
				sig[0]=Boolean.TYPE;
				break;
		case "String":
				sig[0]=String.class;
				break;
		default:
				break;
		
		}
		
	}
}
