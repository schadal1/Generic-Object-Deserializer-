package genericDeser.util;

import genericDeser.logger.Logger;

public class Second {

	private int IntValue;
	private double 	DoubleValue;
	private boolean BooleanValue;
	public static int count=0;

	
    @Override
    public int hashCode() {
        int hash = 7;
        hash = hash * 17 + IntValue;
        hash = hash * 31 + (int)DoubleValue;
        if(BooleanValue)
        hash = hash * 17 + 1;
        else
        hash = hash * 17 + 0;
        return hash;
    }

	
    @Override
    public boolean equals(Object object)
    {

		Logger.writeMessage("Overriden equals() : Comparing 2 Second Objects.", Logger.DebugLevel.one);
    	Second firstObject = (Second) object;
    	
    	if(firstObject.getIntValue()==IntValue)
    	{
    		if(firstObject.getDoubleValue()==DoubleValue)
    		{
    			if(firstObject.getBooleanValue()==BooleanValue)
    			{
    					return true;
    			}
    		}
    	}
    	return false;
    }
    
    
	public static void IncrementCount()
	{
		Logger.writeMessage("A duplicate in Second class found.", Logger.DebugLevel.two);
		++count;
	}
	public int getIntValue() {
		return IntValue;
	}
	public void setIntValue(int intValue) {
		IntValue = intValue;
	}
	public double getDoubleValue() {
		return DoubleValue;
	}
	public void setDoubleValue(double doubleValue) {
		DoubleValue = doubleValue;
	}
	public boolean getBooleanValue() {
		return BooleanValue;
	}
	public void setBooleanValue(boolean booleanValue) {
		BooleanValue = booleanValue;
	}
	
}
