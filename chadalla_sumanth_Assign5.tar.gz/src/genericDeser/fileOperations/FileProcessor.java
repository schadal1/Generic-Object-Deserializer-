package genericDeser.fileOperations;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;
public class FileProcessor {

	private  Scanner input;
	
	private static FileProcessor uniqueInstance;
	FileProcessor(String inputFile)
	{
		try {

	    	input = new Scanner(new File(inputFile));	
	    } 
	    catch (IOException e) {
	        e.printStackTrace();
	        System.exit(0);
	    }	
	}
	public static FileProcessor getInstance(String inputFile)
	{	
		
		if(uniqueInstance==null)
		{
			uniqueInstance=new FileProcessor(inputFile);			
		} 
		
		return uniqueInstance;		
	}
	public String getNextLine()
	{
			return input.nextLine();
	}
	public boolean hasNext()
	{
		return input.hasNextLine();
	}
}
