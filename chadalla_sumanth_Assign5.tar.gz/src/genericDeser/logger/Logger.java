package genericDeser.logger;
public abstract class Logger{
	

    public static enum DebugLevel { zero,one,two };

    private static DebugLevel debugLevel;


    public static void setDebugValue (int levelIn) {
    	switch (levelIn) 
		{
			case 0: debugLevel = DebugLevel.zero;break;
			case 1: debugLevel = DebugLevel.one;break;
			case 2: debugLevel = DebugLevel.two;break;
		}
    }

    public static void setDebugValue (DebugLevel levelIn) {	
    	debugLevel = levelIn;
    }

    // @return None
    public static void writeMessage (String message,DebugLevel levelIn ) 
    {
    	if (levelIn == debugLevel)
    		System.out.println(message);
    }
    
    public static DebugLevel getDebugValue(){
    	return debugLevel;
    }

    public String toString() {
	return "Debug Level is " + debugLevel;
    }
}

